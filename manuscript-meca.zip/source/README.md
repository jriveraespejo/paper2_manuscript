## Quarto Manuscript

This is the repository to generate the Quarto manuscript from the study: *Causes and effects in Dichotomous Comparative Judgments: a plausible information-theoretical system of mechanism*.

