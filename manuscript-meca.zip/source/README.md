## Quarto Manuscript

This is the repository to generate the Quarto manuscript from the study: *Let's talk about Thurstone & Co.: An information-theoretical model for comparative judgments, and its statistical translation*.

